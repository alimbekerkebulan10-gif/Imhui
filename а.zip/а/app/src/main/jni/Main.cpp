#define IMGUI_DEFINE_MATH_OPERATORS
#define LOADERW 960
#define LOADERH 633
#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include "Includes/Utils.h"
#include "includes/Dobby/dobby.h"
#include "Includes/Obfuscate.h"
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include "imgui.h"
#include "imgui_internal.h"
#include "backends/imgui_impl_opengl3.h"
#include "KittyMemory/MemoryPatch.h"
#include "Unity/Quaternion.h"
#include "Unity/Vector3.h"
#include "Unity/Vector2.h"
#include "Unity/Rect.h"
#include "Unity/monoString.h"
#include <Icon/icon.h>
#include <Icon/iconcpp.h>
#include "Font/pixel.h"
#include "Includes/Font.h"
#include "Includes/charObfuscate.h"
#include "Includes/oxorany.h"
#include "Includes/oxorany.cpp"
#include "Includes/oxorany_include.h"

uintptr_t address=0;
bool bool1,bool2;
ImFont* asteria;
ImFont* SkeetNormal;
ImFont* SkeetSmall;
using namespace std;
float alpha;
ImVec4 accentcolor = ImColor(100, 150, 220, 255);
ImColor frame = ImColor(60,60,65,255);
int glWidth,glHeight;
static int tab = 0;
ImFont* font1;
ImFont* font2;
ImFont* asteria2;
ImFont* mainFont;
ImFont* tabFont;
ImFont* smallFont;

#include "Cheat/bools_hooks.h"
#include "Cheat/esp.h"
#include "Cheat/chams.h"

bool testing;
bool menu = false;
float dpiscale = 1.0f;
bool openline = true;

bool crosshair_enabled = true;
float crosshair_size = 20.0f;
float crosshair_thickness = 2.0f;
ImVec4 crosshair_color = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);

void DrawCrosshair() {
    if (!crosshair_enabled) return;
    ImGuiIO& io = ImGui::GetIO();
    ImVec2 center(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f);
    ImDrawList* draw = ImGui::GetForegroundDrawList();
    draw->AddLine(ImVec2(center.x - crosshair_size, center.y),
                  ImVec2(center.x - crosshair_size * 0.3f, center.y),
                  ImColor(crosshair_color), crosshair_thickness);
    draw->AddLine(ImVec2(center.x + crosshair_size * 0.3f, center.y),
                  ImVec2(center.x + crosshair_size, center.y),
                  ImColor(crosshair_color), crosshair_thickness);
    draw->AddLine(ImVec2(center.x, center.y - crosshair_size),
                  ImVec2(center.x, center.y - crosshair_size * 0.3f),
                  ImColor(crosshair_color), crosshair_thickness);
    draw->AddLine(ImVec2(center.x, center.y + crosshair_size * 0.3f),
                  ImVec2(center.x, center.y + crosshair_size),
                  ImColor(crosshair_color), crosshair_thickness);
    draw->AddRectFilled(ImVec2(center.x - 1, center.y - 1),
                        ImVec2(center.x + 1, center.y + 1),
                        ImColor(crosshair_color));
}

void AddColorPicker(const char* name, ImVec4& color, bool prd = false, bool* rainbow = nullptr, bool* pulse = nullptr, bool* dark = nullptr) {
    ImGuiColorEditFlags misc_flags = ImGuiColorEditFlags_AlphaPreview;
    static ImVec4 backup_color;
    bool open_popup = ImGui::ColorButton((std::string(name) + std::string(oxorany("##3b"))).c_str(), color, misc_flags);
    if (open_popup) {
        ImGui::OpenPopup(name);
        backup_color = color;
    }
    if (ImGui::BeginPopup(name)) {
        ImGui::Spacing();
        ImGui::Text(oxorany("%s"), std::string(name).c_str());
        ImGui::Separator();
        ImGui::ColorPicker4(oxorany("##picker"), (float*)&color, misc_flags | ImGuiColorEditFlags_NoSidePreview | ImGuiColorEditFlags_NoSmallPreview | ImGuiColorEditFlags_AlphaBar);
        ImGui::SameLine();
        ImGui::BeginGroup();
        ImGui::Text(oxorany("%s"), std::string(oxorany("current")).c_str());
        ImGui::ColorButton(oxorany("##current"), color, ImGuiColorEditFlags_NoPicker | ImGuiColorEditFlags_AlphaPreviewHalf, ImVec2(60, 40));
        ImGui::Text(oxorany("%s"), std::string(oxorany("previous")).c_str());
        if (ImGui::ColorButton(oxorany("##previous"), backup_color, ImGuiColorEditFlags_NoPicker | ImGuiColorEditFlags_AlphaPreviewHalf, ImVec2(60, 40))) color = backup_color;
        ImGui::EndGroup();
        if (prd) {
            if (rainbow) ImGui::Checkbox(oxorany("rainbow"), rainbow);
            if (pulse) ImGui::Checkbox(oxorany("pulse"), pulse);
            if (dark) ImGui::Checkbox(oxorany("dark"), dark);
        }
        ImGui::Spacing();
        ImGui::EndPopup();
    }
}

const std::string currentDateTime() {
    time_t now = time(0);
    struct tm tstruct;
    char buft[80];
    tstruct = *localtime(&now);
    strftime(buft, sizeof(buft), "%X", &tstruct);
    return buft;
}

bool CustomCheckbox(const char* label, bool* v) {
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems) return false;
    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);
    const ImVec2 label_size = ImGui::CalcTextSize(label, NULL, true);
    const float square_sz = ImGui::GetFrameHeight();
    const ImVec2 pos = window->DC.CursorPos;
    const ImRect total_bb(pos, ImVec2(pos.x + square_sz + (label_size.x > 0.0f ? style.ItemInnerSpacing.x + label_size.x : 0.0f), pos.y + label_size.y + style.FramePadding.y * 2.0f));
    ImGui::ItemSize(total_bb, style.FramePadding.y);
    if (!ImGui::ItemAdd(total_bb, id)) return false;
    bool hovered, held;
    bool pressed = ImGui::ButtonBehavior(total_bb, id, &hovered, &held);
    if (pressed) {
        *v = !(*v);
        ImGui::MarkItemEdited(id);
    }
    const ImRect check_bb(pos, ImVec2(pos.x + square_sz, pos.y + square_sz));
    ImGui::RenderNavHighlight(total_bb, id);
    window->DrawList->AddRect(check_bb.Min, check_bb.Max, frame, style.FrameRounding);
    if (*v) {
        const float pad = ImMax(1.0f, (float)(int)(square_sz / 6.0f));
        window->DrawList->AddRectFilled(ImVec2(check_bb.Min.x + pad, check_bb.Min.y + pad), ImVec2(check_bb.Max.x - pad, check_bb.Max.y - pad), ImColor(accentcolor), style.FrameRounding - pad);
    }
    if (label_size.x > 0.0f) {
        ImGui::RenderText(ImVec2(check_bb.Max.x + style.ItemInnerSpacing.x + (10.0f * dpiscale), check_bb.Min.y + style.FramePadding.y), label);
    }
    return pressed;
}

void DrawMenu() {
    ImGui::GetStyle().Colors[ImGuiCol_CheckMark] = ImColor(accentcolor);

    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImColor(0, 0, 0, 0).Value);
    ImGui::PushStyleColor(ImGuiCol_Border, ImColor(0, 0, 0, 0).Value);

    ImGui::GetStyle().WindowMinSize = ImVec2(0, 0);
    ImGui::SetNextWindowPos(ImVec2(glWidth / 2 - 150 * dpiscale, glHeight - 60 * dpiscale));
    ImGui::SetNextWindowSize(ImVec2(300, 40) * dpiscale);
    ImGui::Begin(oxorany("##openstrip"), &openline, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoResize);

    if (ImGui::InvisibleButton(oxorany("##invisbutton"), ImGui::GetWindowSize()))
        menu = !menu;

    ImGui::GetWindowDrawList()->AddRectFilled(ImVec2(glWidth / 2 - 150 * dpiscale, glHeight - 30 * dpiscale), ImVec2(glWidth / 2 + 150 * dpiscale, glHeight - 10 * dpiscale), ImColor(255, 255, 255, 255), 8 * dpiscale);

    ImGui::PopStyleColor(2);
    ImGui::End();

    if (!menu) return;

    ImGui::SetNextWindowSize(ImVec2(1350, 950), ImGuiCond_FirstUseEver);
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(ImColor(80,80,85)));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 2);
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, 0.92f);

    ImGui::Begin(oxorany("##menu_window"), NULL, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar);
    ImGui::PopStyleColor();

    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.0f, 0.0f, 0.0f, 0.75f));
    ImGui::BeginChild(oxorany("tabs"), ImVec2(1350-20, 70), true);
    ImGui::PopStyleColor();

    float total_tabs_width = 160 * 4;
    float start_x = ((1350-20) - total_tabs_width) / 2;
    ImGui::SetCursorPos(ImVec2(start_x, 12));
    ImGui::BeginGroup();

    auto tab_button = [](const char* label, bool selected) -> bool {
        ImVec4 inactiveBg = ImVec4(0.08f, 0.08f, 0.10f, 0.85f);
        ImVec4 inactiveText = ImVec4(0.85f, 0.85f, 0.90f, 1.0f);
        ImGui::PushStyleColor(ImGuiCol_Button, selected ? ImVec4(0.12f, 0.12f, 0.14f, 0.85f) : inactiveBg);
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, selected ? ImVec4(0.15f, 0.15f, 0.17f, 0.85f) : ImVec4(0.10f, 0.10f, 0.12f, 0.85f));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, selected ? ImVec4(0.10f, 0.10f, 0.12f, 0.85f) : ImVec4(0.07f, 0.07f, 0.09f, 0.85f));
        ImGui::PushStyleColor(ImGuiCol_Text, selected ? ImVec4(accentcolor.x, accentcolor.y, accentcolor.z, 1.0f) : inactiveText);
        ImGui::PushFont(tabFont);
        bool clicked = ImGui::Button(label, ImVec2(160, 44));
        ImGui::PopFont();
        ImGui::PopStyleColor(4);
        return clicked;
    };

    if (tab_button(oxorany("ragebot"), tab == 0)) tab = 0;
    ImGui::SameLine();
    if (tab_button(oxorany("visuals"), tab == 1)) tab = 1;
    ImGui::SameLine();
    if (tab_button(oxorany("misc"), tab == 2)) tab = 2;
    ImGui::SameLine();
    if (tab_button(oxorany("settings"), tab == 3)) tab = 3;

    ImGui::EndGroup();
    ImGui::EndChild();

    ImGui::SetCursorPos(ImVec2(12, 85));
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.0f, 0.0f, 0.0f, 0.75f));
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 8);
    ImGui::BeginChild(oxorany("main"), ImVec2(1350-24, 810), true);

    ImGui::SetCursorPos(ImVec2(15, 15));
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.05f, 0.05f, 0.07f, 0.75f));
    ImGui::BeginChild(oxorany("content"), ImVec2(1350-54, 770), true);

    ImGui::PushFont(mainFont);
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 1.0f, 1.0f, 1.0f));

    if (tab == 0) {
        ImGui::Columns(2, "ragebot_columns", false);
        ImGui::SetColumnWidth(0, 630);

        ImGui::BeginChild(oxorany("aim_column"), ImVec2(0, 0), true);
        ImGui::SetCursorPos(ImVec2(22, 22));
        ImGui::Text(oxorany("aim"));
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        CustomCheckbox(oxorany("silent aim"), &slaim);
        if (slaim) {
        ImGui::Combo(oxorany("current bone"), &currbno, bnnes, IM_ARRAYSIZE(bnnes));
        CustomCheckbox(oxorany("draw fov"), &silentfov);
        ImGui::SameLine();
        AddColorPicker(oxorany("fov color"), aimclr);
        ImGui::SliderFloat(oxorany("fov value"), &aimffv, 0.f, 700.f);
        }
        ImGui::EndChild();

        ImGui::NextColumn();
        ImGui::BeginChild(oxorany("antiaim_column"), ImVec2(0, 0), true);
        ImGui::SetCursorPos(ImVec2(22, 22));
        ImGui::Text(oxorany("antiaim"));
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();
        ImGui::Text(oxorany("error! : functions not found"));
        ImGui::EndChild();
        ImGui::Columns(1);
    }

    if (tab == 1) {
        ImGui::Columns(2, "visuals_columns", false);
        ImGui::SetColumnWidth(0, 630);

        ImGui::BeginChild(oxorany("esp_column"), ImVec2(0, 0), true);
        ImGui::SetCursorPos(ImVec2(22, 22));
        ImGui::Text(oxorany("esp"));
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();
        CustomCheckbox(oxorany("render esp"), &esp_en);
        if(esp_en) {
        CustomCheckbox(oxorany("esp box"), &espbox);
	    CustomCheckbox(oxorany("esp line"), &espline);
        }
        ImGui::EndChild();

        ImGui::NextColumn();
        ImGui::BeginChild(oxorany("other_column"), ImVec2(0, 0), true);
        ImGui::SetCursorPos(ImVec2(22, 22));
        ImGui::Text(oxorany("other"));
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        CustomCheckbox(oxorany("transparent mode"), &opacityChams);
        ImGui::Spacing();
        CustomCheckbox(oxorany("textured"), &texturedChams);
        ImGui::SameLine();
        AddColorPicker(oxorany("visible"), *(ImVec4 *)&visibleTexturedChamsColor, true, &visibleTexturedChamsRainbow, &visibleTexturedChamsPulse);
        ImGui::SameLine();
        AddColorPicker(oxorany("invisible"), *(ImVec4 *)&invisibleTexturedChamsColor, true, &invisibleTexturedChamsRainbow, &invisibleTexturedChamsPulse);
        ImGui::Spacing();
        CustomCheckbox(oxorany("wireframe"), &wireframeChams);
        ImGui::SameLine();
        AddColorPicker(oxorany("wf color"), *(ImVec4 *)&wireframeChamsColor, true, &wireframeChamsRainbow, &wireframeChamsPulse);
        ImGui::Spacing();
        if (wireframeChams) {
            CustomCheckbox(oxorany("wallhack"), &wireframeWallhackChams);
            ImGui::Spacing();
            ImGui::SliderFloat(oxorany("width"), &wireframeWidthChams, 1, 5, "%.1f");
        }
        ImGui::Spacing();
        CustomCheckbox(oxorany("shading"), &shadingChams);
        ImGui::SameLine();
        AddColorPicker(oxorany("sh color"), *(ImVec4 *)&shadingChamsColor);
        ImGui::Spacing();
        if (shadingChams) CustomCheckbox(oxorany("wallhack"), &shadingWallhackChams);
        ImGui::Spacing();
        CustomCheckbox(oxorany("outline"), &outlineChams);
        ImGui::SameLine();
        AddColorPicker(oxorany("ou color"), *(ImVec4 *)&outlineChamsColor, true, &outlineChamsRainbow, &outlineChamsPulse);
        ImGui::Spacing();
        if (outlineChams) {
            CustomCheckbox(oxorany("wallhack"), &outlineWallhackChams);
            ImGui::Spacing();
            ImGui::SliderFloat(oxorany("width"), &outlineWidthChams, 1, 5, "%.1f");
        }
        ImGui::Spacing();
        CustomCheckbox(oxorany("glow"), &glowChams);
        ImGui::SameLine();
        AddColorPicker(oxorany("gl color"), *(ImVec4 *)&glowChamsColor, true, &glowChamsRainbow, &glowChamsPulse);
        ImGui::Spacing();
        CustomCheckbox(oxorany("world color"), &nightmode);
        ImGui::SameLine();
        AddColorPicker(oxorany("color"), *(ImVec4 *)&worldChamsColor, true, &worldChamsRainbow);
        ImGui::EndChild();
        ImGui::Columns(1);
    }

    if (tab == 2) {
        ImGui::Columns(2, "misc_columns", false);
        ImGui::SetColumnWidth(0, 630);

        ImGui::BeginChild(oxorany("exploits_column"), ImVec2(0, 0), true);
        ImGui::SetCursorPos(ImVec2(22, 22));
        ImGui::Text(oxorany("exploits"));
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();
        ImGui::Text(oxorany("not found functions"));
        ImGui::EndChild();

        ImGui::NextColumn();
        ImGui::BeginChild(oxorany("player_column"), ImVec2(0, 0), true);
        ImGui::SetCursorPos(ImVec2(22, 22));
        ImGui::Text(oxorany("player"));
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        CustomCheckbox(oxorany("big head (enemy)"), &bighead);
	    CustomCheckbox(oxorany("air jump"), &airjump);
        ImGui::EndChild();
        ImGui::Columns(1);
    }

    if (tab == 3) {
        ImGui::Columns(1, "setting_column", false);
        ImGui::BeginChild(oxorany("setting_content"), ImVec2(0, 0), true);
        ImGui::SetCursorPos(ImVec2(22, 22));
        ImGui::Text(oxorany("menu settings"));
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::Text("accent color");
        ImGui::SameLine();
        AddColorPicker(oxorany("##accent"), accentcolor);
        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();
        ImGui::Text(oxorany("crosshair"));
        ImGui::Spacing();
        CustomCheckbox(oxorany("enable crosshair"), &crosshair_enabled);
        ImGui::Spacing();
        ImGui::SliderFloat(oxorany("size"), &crosshair_size, 10.0f, 40.0f, "%.1f");
        ImGui::SliderFloat(oxorany("thickness"), &crosshair_thickness, 1.0f, 5.0f, "%.1f");
        ImGui::Text(oxorany("color"));
        ImGui::SameLine();
        AddColorPicker(oxorany("##crosshair_color"), crosshair_color);

        ImGui::EndChild();
        ImGui::Columns(1);
    }

    ImGui::PopStyleColor();
    ImGui::PopFont();

    ImGui::PopStyleColor();
    ImGui::EndChild();
    ImGui::PopStyleVar();

    ImGui::PopStyleColor();
    ImGui::EndChild();

    std::string credits = oxorany("@elystrial & @phantomware");
    ImGui::PushFont(smallFont);
    ImVec2 credits_size = ImGui::CalcTextSize(credits.c_str());
    ImGui::GetWindowDrawList()->AddText(ImVec2(ImGui::GetWindowPos().x + (ImGui::GetWindowSize().x - credits_size.x) / 2, ImGui::GetWindowPos().y + ImGui::GetWindowSize().y - 25), ImColor(200,200,200,200), credits.c_str());
    ImGui::PopFont();

    ImGui::End();
    ImGui::PopStyleVar();
    ImGui::PopStyleVar();
}

void style() {
    ImGuiStyle& style = ImGui::GetStyle();
    style.DpiScale = dpiscale;
    style.Colors[ImGuiCol_WindowBg]      = ImColor(0, 0, 0, 230);
    style.Colors[ImGuiCol_Border]        = ImColor(40, 40, 45, 200);
    style.Colors[ImGuiCol_CheckMark]     = ImColor(accentcolor);
    style.Colors[ImGuiCol_FrameBg]       = ImColor(15, 15, 18, 220);
    style.Colors[ImGuiCol_FrameBgHovered]= ImColor(25, 25, 30, 220);
    style.Colors[ImGuiCol_FrameBgActive] = ImColor(35, 35, 40, 220);
    style.Colors[ImGuiCol_Button]        = ImColor(20, 20, 25, 220);
    style.Colors[ImGuiCol_ButtonHovered] = ImColor(30, 30, 36, 220);
    style.Colors[ImGuiCol_ButtonActive]  = ImColor(45, 45, 52, 220);
    style.Colors[ImGuiCol_Text]          = ImColor(255, 255, 255);
    style.Colors[ImGuiCol_TextDisabled]  = ImColor(140, 140, 150);
    style.Colors[ImGuiCol_ChildBg]       = ImColor(0, 0, 0, 200);
    style.Colors[ImGuiCol_PopupBg]       = ImColor(0, 0, 0, 240);
    style.Colors[ImGuiCol_Separator]     = ImColor(55, 55, 60, 200);
    style.Colors[ImGuiCol_SeparatorHovered] = ImColor(80, 80, 90, 200);
    style.Colors[ImGuiCol_SeparatorActive] = ImColor(100, 100, 110, 200);
    style.Colors[ImGuiCol_Header]        = ImColor(35, 35, 40, 220);
    style.Colors[ImGuiCol_HeaderHovered] = ImColor(45, 45, 52, 220);
    style.Colors[ImGuiCol_HeaderActive]  = ImColor(55, 55, 62, 220);
    style.Colors[ImGuiCol_TitleBg]       = ImColor(0, 0, 0, 200);
    style.Colors[ImGuiCol_TitleBgActive] = ImColor(0, 0, 0, 210);
    style.Colors[ImGuiCol_TitleBgCollapsed] = ImColor(0, 0, 0, 180);
    style.FrameRounding = 4.0f;
    style.GrabRounding = 4.0f;
    style.PopupRounding = 4.0f;
    style.ScrollbarRounding = 4.0f;
    style.TabRounding = 4.0f;
    style.WindowRounding = 8.0f;
    style.ChildRounding = 6.0f;
    style.FrameBorderSize = 0.0f;
    style.WindowBorderSize = 1.0f;
    style.PopupBorderSize = 1.0f;
}

void SetupImgui() {
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)glWidth,(float)glHeight);
    style();
    ImGui_ImplOpenGL3_Init("#version 100");
    io.Fonts->ClearFonts();
    ImFontConfig font_cfg;
    font_cfg.GlyphRanges = io.Fonts->GetGlyphRangesCyrillic();
    io.ConfigWindowsMoveFromTitleBarOnly = false;
    io.IniFilename = NULL;

    SkeetNormal = io.Fonts->AddFontFromMemoryTTF(&PixelFont, sizeof PixelFont, 21, NULL, io.Fonts->GetGlyphRangesCyrillic());
    SkeetSmall = io.Fonts->AddFontFromMemoryTTF(&PixelFont, sizeof PixelFont, 20, NULL, io.Fonts->GetGlyphRangesCyrillic());

    font_cfg.SizePixels = 37.5f;
    mainFont = io.Fonts->AddFontFromMemoryTTF(&Font, sizeof Font, 37.5f, &font_cfg);
    font_cfg.SizePixels = 33.0f;
    tabFont = io.Fonts->AddFontFromMemoryTTF(&Font, sizeof Font, 33.0f, &font_cfg);
    font_cfg.SizePixels = 54.0f;
    asteria = io.Fonts->AddFontFromMemoryTTF(&Font, sizeof Font, 54.0f, &font_cfg);
    font_cfg.SizePixels = 55.5f;
    asteria2 = io.Fonts->AddFontFromMemoryTTF(&Font, sizeof Font, 55.5f, &font_cfg);
    font_cfg.SizePixels = 90.0f;
    font1 = io.Fonts->AddFontFromMemoryTTF(&Font, sizeof Font, 90.0f, &font_cfg);
    font_cfg.SizePixels = 42.0f;
    font2 = io.Fonts->AddFontFromMemoryTTF(&Font, sizeof Font, 42.0f, &font_cfg);
    font_cfg.SizePixels = 18.0f;
    smallFont = io.Fonts->AddFontFromMemoryTTF(&Font, sizeof Font, 18.0f, &font_cfg);

    ImFontConfig cfg;
    cfg.SizePixels = 52.5f;
    io.Fonts->AddFontDefault(&cfg);
}

bool setup = false;

bool HandleInputEvent(JNIEnv*, int, int, int, int);

typedef enum{TOUCH_ACTION_DOWN=0,TOUCH_ACTION_UP,TOUCH_ACTION_MOVE}TOUCH_ACTION;

typedef struct
{
    TOUCH_ACTION action;
    float x;
    float y;
    int pointers;
    float y_velocity;
    float x_velocity;
}TOUCH_EVENT;

TOUCH_EVENT g_LastTouchEvent;

bool HandleInputEvent(JNIEnv* env, int motionEvent, int x, int y, int p)
{
    float velocity_y = (float)((float)y - g_LastTouchEvent.y)/100.f;
    g_LastTouchEvent = {.action = (TOUCH_ACTION)motionEvent, .x = static_cast<float>(x), .y = static_cast<float>(y), .pointers = p, .y_velocity = velocity_y};
    
    ImGuiIO& io = ImGui::GetIO();
    io.MousePos.x = g_LastTouchEvent.x;
    io.MousePos.y = g_LastTouchEvent.y;
    
    if(motionEvent == 2) {
        if(g_LastTouchEvent.pointers > 1) {
            io.MouseWheel = g_LastTouchEvent.y_velocity;
            io.MouseDown[0] = false;
        }
        else
            io.MouseWheel = 0;
    }
    
    if(motionEvent == 0)
        io.MouseDown[0] = true;
    
    if(motionEvent == 1)
        io.MouseDown[0] = false;
    
    return true;
}

bool(*old_nativeInjectEvent)(JNIEnv*, jobject, jobject);
bool hook_nativeInjectEvent(JNIEnv* env, jobject instance, jobject event)
{
    jclass MotionEvent = env->FindClass(("android/view/MotionEvent"));
    if(!env->IsInstanceOf(event, MotionEvent))
        return old_nativeInjectEvent(env, instance, event);
    
    jmethodID id_getAct = env->GetMethodID(MotionEvent, ("getActionMasked"), ("()I"));
    jmethodID id_getX = env->GetMethodID(MotionEvent, ("getX"), ("()F"));
    jmethodID id_getY = env->GetMethodID(MotionEvent, ("getY"), ("()F"));
    jmethodID id_getPs = env->GetMethodID(MotionEvent, ("getPointerCount"), ("()I"));
    
    HandleInputEvent(env, env->CallIntMethod(event, id_getAct), 
                     env->CallFloatMethod(event, id_getX), 
                     env->CallFloatMethod(event, id_getY), 
                     env->CallIntMethod(event, id_getPs));
    
    if(!ImGui::GetIO().MouseDownOwnedUnlessPopupClose[0])
        return old_nativeInjectEvent(env, instance, event);
    
    return false;
}

jint(*old_RegisterNatives)(JNIEnv*, jclass, JNINativeMethod*, jint);
jint hook_RegisterNatives(JNIEnv* env, jclass destinationClass, JNINativeMethod* methods, jint totalMethodCount)
{
    for(int i = 0; i < totalMethodCount; ++i) {
        if(!strcmp(methods[i].name, ("nativeInjectEvent")))
            DobbyHook(methods[i].fnPtr, (void*)hook_nativeInjectEvent, (void**)&old_nativeInjectEvent);
    }
    return old_RegisterNatives(env, destinationClass, methods, totalMethodCount);
}

EGLBoolean(*old_eglSwapBuffers)(EGLDisplay, EGLSurface);
EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface)
{
    eglQuerySurface(dpy, surface, EGL_WIDTH, &glWidth);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &glHeight);
    
    if(!setup) {
        SetupImgui();
        setup = true;
    }
    
    ImGuiIO& io = ImGui::GetIO();
    switch(g_LastTouchEvent.action) {
        case TOUCH_ACTION_MOVE:
            if(g_LastTouchEvent.pointers > 1) {
                io.MouseWheel = g_LastTouchEvent.y_velocity;
                io.MouseDown[0] = false;
            }
            else
                io.MouseWheel = 0;
            break;
        case TOUCH_ACTION_DOWN:
            io.MouseDown[0] = true;
            break;
        case TOUCH_ACTION_UP:
            io.MouseDown[0] = false;
            break;
        default:
            break;
    }
    
    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
	if (silentfov) {
        ImGui::Begin("##dsdsfds", nullptr,
                     ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar |
                     ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar |
                     ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBackground |
                     ImGuiWindowFlags_NoMouseInputs);
        auto draw = ImGui::GetBackgroundDrawList();
        draw->AddCircle(ImVec2(glWidth / 2, glHeight / 2), aimffv,
                        ImGui::ColorConvertFloat4ToU32(aimclr), 100, 1.5f);
        ImGui::End();
    }
	
    DrawMenu();
	DrawESP();
    
    ImGui::EndFrame();
    ImGui::Render();
    glViewport(0, 0, (int)io.DisplaySize.x, (int)io.DisplaySize.y);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    
    return old_eglSwapBuffers(dpy, surface);
}

void* hack_thread(void*)
{
    while(!isLoaded()) {
        usleep(10000);
    }
	Wallhack();
    
    auto addr = (uintptr_t)dlsym(RTLD_NEXT, "eglSwapBuffers");
    DobbyHook((void*)addr, (void*)hook_eglSwapBuffers, (void**)&old_eglSwapBuffers);
    
DobbyHook((void *) KittyMemory::getAbsoluteAddress("libil2cpp.so", oxorany(0x2092EA4)), (void *) PlayerController_Update, (void **) &old_PlayerController_Update); 
DobbyHook((void *) KittyMemory::getAbsoluteAddress("libil2cpp.so", oxorany(0x213F99C)), (void *) CastBullet, (void **) &old_CastBullet); 
DobbyHook((void *) KittyMemory::getAbsoluteAddress("libil2cpp.so", oxorany(0x20909B4)), (void *) ChamsBP, (void **) &old_ChamsBP); 
DobbyHook((void *) KittyMemory::getAbsoluteAddress("libil2cpp.so", oxorany(0x1C5B700)), (void *) isGrounded, (void **) &old_isGrounded); 
//DobbyHook((void *) KittyMemory::getAbsoluteAddress("libil2cpp.so", oxorany(0x12E3AB0)), (void *) BunnyHope, (void **) &old_BunnyHope);  

WorldToScreenPoint = (Vector3(*)(void *,Vector3)) KittyMemory::getAbsoluteAddress("libil2cpp.so", oxorany(0x17D6478)); 
GetPlayerHealth = (int (*)(void *)) KittyMemory::getAbsoluteAddress("libil2cpp.so", oxorany(0x2601158)); 
get_bipedmap = (void *(*)(void *)) KittyMemory::getAbsoluteAddress("libil2cpp.so", oxorany(0x20924A0)); 
get_forward = (Vector3(*)(void*)) KittyMemory::getAbsoluteAddress("libil2cpp.so", oxorany(0x1AB997C));  
get_transform = (void *(*)(void *)) KittyMemory::getAbsoluteAddress("libil2cpp.so", oxorany(0x17D8E00)); 
get_position = (Vector3(*)(void*)) KittyMemory::getAbsoluteAddress("libil2cpp.so", oxorany(0x1AB9134)); 
get_camera = (void *(*)()) KittyMemory::getAbsoluteAddress("libil2cpp.so", oxorany(0x17D695C)); 
set_localScale = (void (*)(void*, Vector3)) KittyMemory::getAbsoluteAddress("libil2cpp.so", oxorany(0x1AB9CC0));

    pthread_exit(nullptr);
    return nullptr;
}

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved)
{
    JNIEnv* globalEnv;
    vm->GetEnv((void**)&globalEnv, JNI_VERSION_1_6);
    
    DobbyHook((void*)globalEnv->functions->RegisterNatives, 
              (void*)hook_RegisterNatives, 
              (void**)&old_RegisterNatives);
    
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
    
    return JNI_VERSION_1_6;
}
