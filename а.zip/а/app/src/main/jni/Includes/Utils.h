#include <jni.h>
#include <unistd.h>
#include <cstdio>
#include <cstring>
#include <string>
#include <cstdlib>

typedef unsigned long DORD;

bool libLoaded = false;
const char *libName = "libil2cpp.so";

DORD findLibrary(const char *library)
{
	char filename[0xFF] = {0},
		 buffer[1024] = {0};
	FILE *fp = NULL;
	DORD address = 0;
	sprintf(filename, "/proc/self/maps");
	fp = fopen(filename, "rt");
	if (fp == NULL)
	{
		perror("fopen");
		goto done;
	}

	while (fgets(buffer, sizeof(buffer), fp))
	{
		if (strstr(buffer, library))
		{
			address = (DORD)strtoul(buffer, NULL, 16);
			goto done;
		}
	}
done:
	if (fp)
		fclose(fp);
	return address;
}
DORD getAddress(DORD relativeAddr)
{
	return (reinterpret_cast<DORD>(findLibrary(libName) + relativeAddr));
}

bool isLoaded()
{
	char line[512] = {0};
	FILE *fp = fopen("/proc/self/maps", "rt");
	if (fp != NULL)
	{
		while (fgets(line, sizeof(line), fp))
		{
			std::string a = line;
			if (strstr(line, libName))
			{
				return true;
			}
		}
		fclose(fp);
	}
	return false;
}

uintptr_t string2Offset(const char *c) {
    int base = 16;
    // See if this function catches all possibilities.
    // If it doesn't, the function would have to be amended
    // whenever you add a combination of architecture and
    // compiler that is not yet addressed.
    static_assert(sizeof(uintptr_t) == sizeof(unsigned long)
                  || sizeof(uintptr_t) == sizeof(unsigned long long),
                  "Please add string to handle conversion for this architecture.");

    // Now choose the correct function ...
    if (sizeof(uintptr_t) == sizeof(unsigned long)) {
        return strtoul(c, nullptr, base);
    }

    // All other options exhausted, sizeof(uintptr_t) == sizeof(unsigned long long))
    return strtoull(c, nullptr, base);
}
