// PLAYERS // PLAYERS // PLAYERS // PLAYERS;
std::vector<void*> players;
void* myPlayer = nullptr;
void* enemyPlayer = nullptr;
void *aimedplayer = nullptr;

// VARIABLES // VARIABLES // VARIABLES // VARIABLES
bool bighead, airjump, bhop;
float bhopvalue = 7.5f;

bool slaim, silentfov;
const char* bnnes[] = {"Head", "Neck", "Hip"};
int currbno = 0;
float aimffv = 30.0f;
ImVec4 aimclr = ImVec4(255,0,0,255);

bool esp_en, espbox, espline;

// HOOKS // HOOKS // HOOKS // HOOKS // HOOKS
Vector3 (*WorldToScreenPoint)(void* camera, Vector3 positon);
Vector3 (*get_position)(void*transform);
Vector3(*get_forward) (void*);
void *(*get_bipedmap)(void *player);
void *(*get_camera)();
void *(*get_transform)(void *instance);
void (*set_localScale)(void *transform, Vector3 newScale);
int(*GetPlayerHealth)(void* popachka);

// CASTS // CASTS // CASTS // CASTS // CASTS // CASTS
static void *get_photon(void *player) { 
   return *(void **) ((uint64_t) player + oxorany(0x120)); 
}

void *get_head(void *player) {
    return *(void **)((uint64_t) get_bipedmap(player) + oxorany(0x18));
}

void *get_neck(void *player) { 
   return *(void **)((uint64_t) get_bipedmap(player) + oxorany(0x20)); 
}

void *get_hip(void *player) { 
   return *(void **)((uint64_t) get_bipedmap(player) + oxorany(0x78)); 
}

bool IsLocal(void *photon) { 
   return *(bool *) ((uint64_t) photon + oxorany(0x28)); 
}

uint8_t GetTeam(void* player) {
  return *(uint8_t *) ((uint64_t) player + oxorany(0x49));
}

Vector3 GetPlayerLocation(void *player) {
    Vector3 location;
    location = get_position(get_transform(player));
    return location;
}

void clearPlayers() {
    std::vector<void*> pls;
    for (int i = 0; i < players.size(); i++) {
        if (players[i] != NULL&&get_photon(players[i])!=NULL&&GetPlayerHealth(get_photon(players[i]))>0&&myPlayer&&GetTeam(players[i])!=GetTeam(myPlayer)) {
            pls.push_back(players[i]);
        }
    }
    players = pls;
}

bool IsPlayerDead(void *player) {
    if (player) {
        int health = GetPlayerHealth(player);
        if (health <= 0) {
            return true;
        }
    }
    return false;
}

bool playerFind(void *pl) {
    if (pl != NULL) {
        for (int i = 0; i < players.size(); i++) {
            if (pl == players[i]) return true;
        }
    }
    return false;
}

// FUNCTIONS // FUNCTIONS // FUNCTIONS // FUNCTIONS // FUNCTIONS
void (*old_PlayerController_Update)(void* player);
void PlayerController_Update(void* player) {
if (player != nullptr) {
if (IsLocal(get_photon(player))) {
myPlayer = player;
}
   // Проверяем, что myplayer установлен и не мёртв
    if (!myPlayer || !get_photon(myPlayer) || IsPlayerDead(get_photon(myPlayer))) {
        return;
    }
    // Определяем enemyPlayer (если это враг)
    if (GetTeam(player) != GetTeam(myPlayer)) {
        enemyPlayer = player;
    }
    // Проверяем enemyPlayer на валидность
    if (enemyPlayer && (!get_photon(enemyPlayer) || IsPlayerDead(get_photon(enemyPlayer)))) {
        enemyPlayer = nullptr;
    }
	
    // Silent Aim логика (только если enemyplayer валиден)
    if (slaim && enemyPlayer && !IsPlayerDead(get_photon(enemyPlayer))) {
        void* crurbones = nullptr;
        switch (currbno) {
            case 0: crurbones = get_head(enemyPlayer); break;
            case 1: crurbones = get_neck(enemyPlayer); break;
            case 2: crurbones = get_hip(enemyPlayer); break;
        }

        if (crurbones) {
            Vector3 target = get_position(crurbones) - get_position(get_transform(get_camera()));
            float aimAngle = Vector3::Angle(target, get_forward(get_transform(get_camera())) * 100);
            if (target != Vector3(0, 0, 0) && aimAngle <= aimffv / 700.0f) {
                aimedplayer = enemyPlayer;
            }
        }
    } else {
        aimedplayer = nullptr;
    }
	
if(myPlayer){
if (GetTeam(myPlayer) != GetTeam(player)) {
enemyPlayer = player;
}
if(enemyPlayer){
if (bighead) {
set_localScale(get_transform(get_head(enemyPlayer)), Vector3(5, 5, 5));
} else {
set_localScale(get_transform(get_head(enemyPlayer)), Vector3(1,1,1));
}
}}}
if (!playerFind(player)) { 
players.push_back(player);
clearPlayers();
}
old_PlayerController_Update(player);
}

void* (*old_CastBullet)(Vector3 startPosition, Vector3 direction,  void* parameters);
void* CastBullet(Vector3 startPosition, Vector3 direction, void* parameters) {
    if (!slaim) {
        return old_CastBullet(startPosition, direction, parameters);
    }

    // Проверяем все необходимые указатели
    if (!get_camera() || !myPlayer || !get_photon(myPlayer) || IsPlayerDead(get_photon(myPlayer))) {
        return old_CastBullet(startPosition, direction, parameters);
    }

    // Проверяем aimedplayer и его кости
    if (!aimedplayer || !get_photon(aimedplayer) || IsPlayerDead(get_photon(aimedplayer))) {
        return old_CastBullet(startPosition, direction, parameters);
    }

    void* crurbones = nullptr;
    switch (currbno) {
        case 0: crurbones = get_head(aimedplayer); break;
        case 1: crurbones = get_neck(aimedplayer); break;
        case 2: crurbones = get_hip(aimedplayer); break;
    }

    if (!crurbones) {
        return old_CastBullet(startPosition, direction, parameters);
    }

    Vector3 targetPos = get_position(crurbones);
    if (targetPos == Vector3(0, 0, 0)) {
        return old_CastBullet(startPosition, direction, parameters);
    }

    // Меняем направление пули только если всё валидно
    direction = Vector3::Normalize(targetPos - startPosition);
    return old_CastBullet(startPosition, direction, parameters);
}

bool chamsbp = true;
bool (*old_ChamsBP)(void *instance);
bool ChamsBP(void *instance) {
    if (chamsbp) {
        return false;
    }
    return old_ChamsBP(instance);
}

bool (*old_isGrounded)(void* inst);
bool isGrounded(void* inst) {
    if (inst != NULL && airjump) {
       return true;
    } else {
       return old_isGrounded(inst);
    }
}

float (*old_BunnyHope)(void *player);
float BunnyHope(void *player) {
    if (player && bhop) {
        return bhopvalue;
    }
    return old_BunnyHope(player);
}
