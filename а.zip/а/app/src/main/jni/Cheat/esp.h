void DrawESP() {
if (esp_en) {
        clearPlayers();
        for (int i = 0; i < players.size(); i++) {
            if (players[i] != NULL) {
                void *Player = players[i];
                
                int teamId = GetTeam(Player);
                if (teamId == -1) continue;
                
                Vector3 playerpos = get_position(get_transform(Player));
                Vector3 lower_pos = WorldToScreenPoint(get_camera(), Vector3(playerpos.x, playerpos.y, playerpos.z));
                
                Vector3 playerpos_up = get_position(get_transform(Player)) + Vector3(0, 1.9f, 0);
                Vector3 upper_pos = WorldToScreenPoint(get_camera(), Vector3(playerpos_up.x, playerpos_up.y, playerpos_up.z));
                
                int Height = upper_pos.y - lower_pos.y;
                int Width = Height * 0.6;
                
                if (upper_pos.z > 1.0f) {
                    if (espline) {
                        ImGui::GetBackgroundDrawList()->AddLine(ImVec2(glWidth / 2, glHeight), ImVec2(lower_pos.x, glHeight - lower_pos.y), ImGui::ColorConvertFloat4ToU32(ImVec4(255,255,255,255)), 2);
                        ImGui::GetBackgroundDrawList()->AddLine(ImVec2(glWidth / 2, glHeight), ImVec2(lower_pos.x, glHeight - lower_pos.y), ImGui::ColorConvertFloat4ToU32(ImVec4(255,255,255,255)), 1);
                    }
                    if (espbox) {
                        ImGui::GetBackgroundDrawList()->AddRect(ImVec2(upper_pos.x - Width/2, glHeight - upper_pos.y), ImVec2(upper_pos.x + Width/2, glHeight - upper_pos.y + Height), ImGui::ColorConvertFloat4ToU32(ImVec4(255,255,255,255)), 0, 0, 2);
                        ImGui::GetBackgroundDrawList()->AddRect(ImVec2(upper_pos.x - Width/2, glHeight - upper_pos.y), ImVec2(upper_pos.x + Width/2, glHeight - upper_pos.y + Height), ImGui::ColorConvertFloat4ToU32(ImVec4(255,255,255,255)), 0, 0, 1);
                    }
            }
        }
    }
   }
    ImGui::End();
}

